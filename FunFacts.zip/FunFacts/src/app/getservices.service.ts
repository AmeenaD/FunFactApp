import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class GetservicesService {
  url:string="https://cat-fact.herokuapp.com/facts/random?animal_type=cat&amount=2";
  constructor(private _http: HttpClient) { }
  getAllUsers() {
    return this._http.get(this.url);
  }
}
