import { GetservicesService } from './../getservices.service';
import { Component, OnInit } from '@angular/core';
import { CAT } from '../class';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
arr:CAT[]=[];
  constructor(private _data:GetservicesService) { }

  ngOnInit() {
    this._data.getAllUsers().subscribe(
      (data:CAT[])=>{
        this.arr=data;
        console.log(this.arr);
      }
    );
  }
}
