export class CAT {
  public constructor(
    public used: boolean,
    public source:string,
    public type:string,
    public deleted:boolean,
    public _id:string,
    public user:string,
    public text:string,
    public updatedAt:string,
    public  createdAt:string,

  ) {}
}
